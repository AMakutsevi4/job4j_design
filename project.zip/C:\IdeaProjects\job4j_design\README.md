#job4j_design
[![Build Status](https://travis-ci.com/AMakutsevi4/job4j_design.svg?branch=master)](https://travis-ci.com/AMakutsevi4/job4j_design)
[![codecov](https://codecov.io/gh/AMakutsevi4/job4j_design/branch/master/graph/badge.svg?token=tcg39QdiJf)](https://codecov.io/gh/AMakutsevi4/job4j_design)

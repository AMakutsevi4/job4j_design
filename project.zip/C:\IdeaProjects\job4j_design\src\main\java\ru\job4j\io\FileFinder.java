package ru.job4j.io;
/**
import java.io.File;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
*/
public class FileFinder {
    /**
    public List<Path> paths = new ArrayList<>();
    public static void main(String[] args) {
        readFiles(new File(args[0]));
    }

    public static void readFiles(File baseDirectory){
        if (baseDirectory.isDirectory()){
            for (File file : Objects.requireNonNull(baseDirectory.listFiles())) {
                if(file.isFile()){

                    System.out.println(file.getName() + " файл");

                }else {
                    System.out.println(file.getName() + " каталог");
                    readFiles(file);
                }
            }
        }
    }
*/
}
